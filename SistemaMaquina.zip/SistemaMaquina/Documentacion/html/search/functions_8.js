var searchData=
[
  ['ventaspuertas_0',['ventasPuertas',['../state_machine_8ino.html#a43378b397a700a3bd78eb678cc9c4ea1',1,'stateMachine.ino']]]
];
