var searchData=
[
  ['value_0',['value',['../_sistema_maquina_8ino.html#a4e630859cc0e2a22bd6acf39a6a8e218',1,'SistemaMaquina.ino']]]
];
