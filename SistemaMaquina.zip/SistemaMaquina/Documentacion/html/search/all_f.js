var searchData=
[
  ['value_0',['value',['../_sistema_maquina_8ino.html#a4e630859cc0e2a22bd6acf39a6a8e218',1,'SistemaMaquina.ino']]],
  ['ventaspuertas_1',['ventasPuertas',['../state_machine_8ino.html#a43378b397a700a3bd78eb678cc9c4ea1',1,'stateMachine.ino']]]
];
