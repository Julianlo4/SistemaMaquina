var searchData=
[
  ['dht_0',['DHT',['../_sistema_maquina_8ino.html#aff26b1d15dd10336e33d0138e24aa8df',1,'SistemaMaquina.ino']]],
  ['duraciones_1',['duraciones',['../sound_8h.html#afad1aadfe2a34a0e275310caffbd4c06',1,'sound.h']]]
];
