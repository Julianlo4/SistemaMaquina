var searchData=
[
  ['tiemposalida1_0',['tiempoSalida1',['../_sistema_maquina_8ino.html#a64d72200f3ee2dfc211b55b5bd634e7c',1,'SistemaMaquina.ino']]],
  ['tiemposalida2_1',['tiempoSalida2',['../_sistema_maquina_8ino.html#a3ecb7e328fecef12a64ef93dd87a1890',1,'SistemaMaquina.ino']]],
  ['tiemposalida3_2',['tiempoSalida3',['../_sistema_maquina_8ino.html#a0f5346533356ea567b4b3690aa19e60d',1,'SistemaMaquina.ino']]]
];
