var searchData=
[
  ['eventopuertaventana_0',['eventoPuertaVentana',['../_sistema_maquina_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8af4649cce791bebf507485ac6bb82e3b6',1,'SistemaMaquina.ino']]]
];
