var searchData=
[
  ['senialcuatro_0',['senialCuatro',['../_sistema_maquina_8ino.html#a080a822f0093973313bd644e517a5090ade944e95fc7ae86940030f573e0fc878',1,'SistemaMaquina.ino']]],
  ['senialdos_1',['senialDos',['../_sistema_maquina_8ino.html#a080a822f0093973313bd644e517a5090a0bec469890c6a806efefe47e0ec8ec71',1,'SistemaMaquina.ino']]],
  ['senialtres_2',['senialTres',['../_sistema_maquina_8ino.html#a080a822f0093973313bd644e517a5090ae60098f842dadc274a375e0a40a23737',1,'SistemaMaquina.ino']]],
  ['senialuno_3',['senialUno',['../_sistema_maquina_8ino.html#a080a822f0093973313bd644e517a5090af6749e663b7ac48560ea357f9a0e833a',1,'SistemaMaquina.ino']]]
];
