var searchData=
[
  ['alarmaambiental_0',['alarmaAmbiental',['../_sistema_maquina_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a0170afb9c2c4f35617106ca58dda3568',1,'SistemaMaquina.ino']]],
  ['alertaseguridad_1',['alertaSeguridad',['../_sistema_maquina_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a98f05931960ae4ea52b10b76c3a6d596',1,'SistemaMaquina.ino']]]
];
