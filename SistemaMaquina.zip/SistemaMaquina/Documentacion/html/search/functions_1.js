var searchData=
[
  ['inicializarcomponentes_0',['inicializarComponentes',['../_sistema_maquina_8ino.html#ab4a810680471baa7608bf17e48883123',1,'SistemaMaquina.ino']]],
  ['inicilizarcomponentes_1',['inicilizarComponentes',['../_sistema_maquina_8ino.html#ae7557ae93ec331fb324b37cd1e14c887',1,'SistemaMaquina.ino']]]
];
