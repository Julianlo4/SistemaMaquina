var indexSectionsWithContent =
{
  0: "abcdeiklmnprstuvw",
  1: "cps",
  2: "ailmrstuv",
  3: "abcdiklmprtuvw",
  4: "is",
  5: "aeimsu",
  6: "bdln"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros"
};

