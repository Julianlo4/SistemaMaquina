var searchData=
[
  ['constumchar_2eh_0',['ConstumChar.h',['../_constum_char_8h.html',1,'']]]
];
