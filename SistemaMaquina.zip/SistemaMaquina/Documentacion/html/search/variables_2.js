var searchData=
[
  ['colpins_0',['colPins',['../pin_out_8h.html#a3c964a40ceee38dff58e11bf85ebcf5e',1,'pinOut.h']]],
  ['currentinput_1',['currentInput',['../_sistema_maquina_8ino.html#a0563e10870312b52f7f25cfddf778db0',1,'SistemaMaquina.ino']]]
];
