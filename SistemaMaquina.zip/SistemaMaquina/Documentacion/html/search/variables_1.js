var searchData=
[
  ['block_0',['Block',['../_constum_char_8h.html#a98525351f6dca29fc649ca314098e173',1,'ConstumChar.h']]]
];
